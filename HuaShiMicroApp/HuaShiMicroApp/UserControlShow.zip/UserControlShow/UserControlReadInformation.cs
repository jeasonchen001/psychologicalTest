﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HuaShiMicroApp.UserControlShow
{
    //声明委派
    public delegate void clickStart(); 

    public partial class UserControlReadInformation : UserControl
    {
        public UserControlReadInformation()
        {
            InitializeComponent();
        }

        //委托事件
        public event clickStart startButtonClicked;
        
        private void UserControlReadInformation_Load(object sender, EventArgs e)
        {
           //加载必读信息
            String information = ConfigAppSettings.GetValue("information");
            informationText.Text = information;
        }

        // 启动按钮，启动通知image控件启动
        private void Start_Click(object sender, EventArgs e)
        {
            //启动后隐藏整个userControl
            this.Visible = false;
            this.Enabled = false;
            //将启动的消息发送给UserControlImage
            startButtonClicked();
           
        }
    }
}
