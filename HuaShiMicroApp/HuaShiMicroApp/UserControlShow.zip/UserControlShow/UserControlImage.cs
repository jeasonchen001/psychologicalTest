﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace HuaShiMicroApp.UserControlShow
{
    public partial class UserControlImage : UserControl
    {
        public UserControlImage()
        {
            InitializeComponent();
        }

        Random random = new Random();

        public int chooseNum;

        public List<String> group1Images;

        public List<String> group2Images;

        public String showGroup;

        // 当前展示过的两个图像
        public List<String> currentShowImages = new List<String>(2);

        private void UserControlImage_Load(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
            this.closeButton(Option1);
            this.closeButton(Option2);
            // 绑定委托事件
            
            // 加载必读信息
            int interval1 = 1000;
            int interval2 = 1000;
            int.TryParse(ConfigAppSettings.GetValue("interval1"), out interval1);
            int.TryParse(ConfigAppSettings.GetValue("interval2"), out interval2);
            // 设置定时器的间隔
            timer1.Interval = interval1;
            timer2.Interval = interval2;
            //获取exe执行的路径
            String rootPath = AppDomain.CurrentDomain.BaseDirectory;
            //拼接上group1和group2两个路径
            String group1Directory = String.Format("{0}group1", rootPath);
            String group2Directory = String.Format("{0}group2", rootPath);
            //列出所有的文件
            String[] group1Paths = Directory.GetFiles(group1Directory);
            Console.WriteLine("1231");
            group1Images = new List<String>(group1Paths);
            String[] group2Paths = Directory.GetFiles(group2Directory);
            group2Images = new List<String>(group2Paths);
            int group1Size = group1Images.Count();
            int group2Size = group2Images.Count();
            this.chooseNum = Math.Min(group1Size, group2Size);//总共显示的组数
        }

        //从集合中随机抽取一张图片，然后返回抽出图片后的图片集合
        private int randImage(List<String> images)
        {
            int randIndex = random.Next(0, images.Count);
            return randIndex;
        }

        //收到开始图片放映的消息
        private void Start_Click(object sender, EventArgs e)
        {
            //其实先随机抽取一张group1的图片
            int randIndex = randImage(group1Images);
            //imageBox.Image = group1Images[randIndex];
            imageBox.Load(group1Images[randIndex]);
            currentShowImages.Add(group1Images[randIndex]);
            group1Images.RemoveAt(randIndex);
            timer1.Start();
        }

        /// <summary>
        /// 1.定时器1计时结束,关闭计时器1.
        /// 2.抽取第二组图片，显示第二组的抽取的图片,并开启定时器2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            int randIndex = randImage(group2Images);
            imageBox.Load(group1Images[randIndex]);
            currentShowImages.Add(group1Images[randIndex]);
            group2Images.RemoveAt(randIndex);
            timer2.Start();
        }

        /// <summary>
        /// 1.定时器2计时结束
        /// 2.在展示的前两张图片中随机抽取一张
        /// 3.等待用户选择
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            int randIndex = randImage(currentShowImages);
            if (randIndex == 0)
            { this.showGroup = "group1"; }
            else{
                this.showGroup = "group2";
            }
            imageBox.Load(currentShowImages[randIndex]);
            currentShowImages.Clear();
            //显示选择按钮
            this.openButton(Option1);
            this.openButton(Option2);
        }

        // 用户选择组1
        private void Option1_Click(object sender, EventArgs e)
        {
            //记录用户的选择
            bool result = judgeChooseRight("group1");
        }

        //用户选择组2
        private void Option2_Click(object sender, EventArgs e)
        {
            bool result = judgeChooseRight("group2");
        }

        private void closeButton(Button button) {
            button.Visible = false;
            button.Enabled = false;
        }

        private void openButton(Button button) {
            button.Visible = true;
            button.Enabled = true;
        }

        //判断用户判断是否正确
        private bool judgeChooseRight(String chooseGroup) {
            bool result = (chooseGroup == this.showGroup);
            // 将showGroup清空
            showGroup = String.Empty;
            return result;
        }

        // 将结果进行保存
        private void saveResult(String result) {
        }
    }
}
